console.log("Name:guest");
console.log("Class: TE");
console.log("Subject:LP-2 WAD");
console.log("Ass2");
